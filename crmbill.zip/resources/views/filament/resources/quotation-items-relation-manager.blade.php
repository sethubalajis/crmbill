<div class="fi-resource-relation-manager">
    {{ $this->content }}

    <x-filament-panels::unsaved-action-changes-alert />
</div>
