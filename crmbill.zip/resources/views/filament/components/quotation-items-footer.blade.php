<div class="px-4 py-3 bg-gray-50 border-t border-gray-200 dark:bg-gray-800 dark:border-gray-700">
    <div class="flex justify-between">
        <span class="font-semibold text-gray-900 dark:text-gray-100">Total:</span>
        <span class="font-semibold text-lg text-gray-900 dark:text-gray-100">{{ $total }}</span>
    </div>
</div>
